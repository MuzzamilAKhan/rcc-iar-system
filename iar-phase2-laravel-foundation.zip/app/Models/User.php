<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use HasFactory, Notifiable, HasRoles;

    protected $fillable = ['name','email','password','position','business_unit_id','is_active'];
    protected $hidden = ['password','remember_token'];
    protected function casts(): array { return ['email_verified_at'=>'datetime','password'=>'hashed','is_active'=>'boolean']; }
    public function businessUnit(): BelongsTo { return $this->belongsTo(BusinessUnit::class); }
    public function createdIars(): HasMany { return $this->hasMany(ImpactAssessment::class,'creator_id'); }
    public function assignedIars(): HasMany { return $this->hasMany(IarAssignment::class,'assigned_to_user_id'); }
    public function countryAssessorMappings(): HasMany { return $this->hasMany(CountryAssessor::class); }
}
