# Regulatory IAR — Phase 2 Foundation Overlay

**Scope:** Phase 2 foundation overlay for a new **Laravel 12 + Livewire starter kit + Tailwind + MySQL 8** project. This is NOT a complete Laravel application or the Phase 3–6 application. It supplies 3 migrations, 17 models including User, 5 enums, 3 seeders and foundation tests. Laravel starter-kit authentication/UI and Spatie RBAC schema are installed separately.

## Prerequisites

- PHP >= 8.3 with required Laravel extensions
- Composer, Node.js/npm, MySQL 8
- Laravel installer (`composer global require laravel/installer`)

## Install (clean new project, interactive)

```bash
laravel new regulatory-iar
# Choose Laravel 12, Livewire starter kit, MySQL, PHPUnit when asked.
cd regulatory-iar
composer require spatie/laravel-permission:^7.0
php artisan vendor:publish --provider="Spatie\\Permission\\PermissionServiceProvider"
# Configure .env with correct DB_DATABASE / DB_USERNAME / DB_PASSWORD first.
# COPY CONTENTS OF THIS OVERLAY INTO YOUR NEW PROJECT ROOT, merging directories.
# In particular app/Models/User.php and database/seeders/DatabaseSeeder.php are deliberately replaced.
php artisan optimize:clear
php artisan migrate --seed
npm install
npm run build
php artisan test
composer run dev
```

If the installer defaults to a different Laravel major version, explicitly select or pin Laravel 12 before applying. Spatie v7 requires PHP >= 8.3 and Laravel 12+. Do not run migrations before publishing Spatie's tables and applying the overlay. Keep the Laravel starter kit's pre-existing `create_users_table`, sessions, cache and jobs migrations. Do not duplicate these tables.

## Migration order

1. Starter kit `users`/cache/jobs migration (standard Laravel timestamp 0001_01_01...)
2. Spatie permission tables (published migration)
3. `2026_10_20_000001_create_iar_reference_tables`
4. `2026_10_20_000002_create_iar_business_tables`
5. `2026_10_20_000003_create_iar_operations_tables`

If Spatie's published migration has a timestamp after 2026-10-20, migrations are still valid as none of ours require its tables; Spatie's tables must be in place before seeding roles.

## Locked product rules

- Unknown SAP: create assignment exception; do **not** normally issue until resolved.
- Backup: priority 1 primary, priority 2 fallback with authorized reassignment.
- Submitted assessment: locked until authorized reopen.
- Due date: 14 **calendar** days after creation; calculate in application service, store UTC.

**These rules are specified but their business services are deliberately NOT yet implemented by this foundation package.** The Phase 2 tests verify schema/RBAC/enums only, not the entire IAR workflow. No email/UI/Excel/assignment engine is implemented yet.

## Important follow-up before production

- SAP uniqueness scope; multiple registration records per country; active-registration semantics; Excel column mappings.
- Country-region mapping (EU/UK/USA vs other) approval.
- Enforce `assignment_priority` in {1,2} at request/service + database constraint where supported.
- Enforce exactly one attachment parent and complete per-record authorization and audit logging.
- Prevent edits of submitted assessments in services/policies; enforce idempotent assignment and email delivery.
- Handle user status, creator/assessor authorization, race conditions, and export access.
- Disallow public registration on production starter kit unless specifically required.
- Real production deployment requires CI, security review, queue worker, backups, restore testing and end-to-end tests.

## Verification

```bash
php artisan migrate:status
php artisan db:seed --class=RolesAndPermissionsSeeder
php artisan test --filter=SchemaFoundationTest
php artisan test --filter=DomainEnumTest
```

The overlay's PHP files were syntax-checked at generation time. Runtime Laravel migrations/tests must be executed in an installed Laravel application.
